package com.application.moviecatalogue.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}