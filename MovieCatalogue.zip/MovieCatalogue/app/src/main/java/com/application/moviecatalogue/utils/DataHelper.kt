package com.application.moviecatalogue.utils

object DataHelper {
    const val MOVIE = "MOVIE"
    const val TV_SHOW = "TV_SHOW"
}